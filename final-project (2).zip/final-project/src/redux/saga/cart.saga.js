import { put, takeLatest } from "redux-saga/effects";
import { ADD_ITEM_TO_CART_START, GET_CART_START } from "../constants/cart.constant";
import { addCartToFirebase, getCartFromFirebase } from "../sevices/cart.service";
import { addItemToCartError, getCartError, getCartStart, getCartSuccess } from "../actions/cart.action";

function* addUser({payload}) {
    try {
        yield addCartToFirebase(payload)
        yield put(getCartStart())
    } catch (error) {
        yield put(addItemToCartError(error.message))
    }
}

function* getUser() {
    try {
        let cart = yield getCartFromFirebase()
        yield put(getCartSuccess(cart))
    } catch (error) {
        yield put(getCartError(error.message))
    }
}

export default function* cart() {
    yield takeLatest(ADD_ITEM_TO_CART_START, addUser);
    yield takeLatest(GET_CART_START, getUser);
}