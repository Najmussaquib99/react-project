import {
    collection,
    addDoc,
    query,
    getDocs,
} from "firebase/firestore";
import {
    db
} from "../../firebase.config";

export const addCartToFirebase = async (cart) => {

    let cartRef = collection(db, "carts")

    const docRef = await addDoc(cartRef, cart);

    console.log("Document written with ID: ", docRef.id);
}

export const getCartFromFirebase = async () => {

    let cartRef = query(collection(db, "carts"))

    const querySnapshot = await getDocs(cartRef);

    let carts = [];

    querySnapshot.forEach((doc) => {

        let prod = doc.data()

        prod.id = doc.id;

        carts.push(prod);
    });

    return carts;
}
