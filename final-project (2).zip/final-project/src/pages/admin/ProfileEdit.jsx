import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';
import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { storage } from '../../firebase.config';
import { updateUserStart } from '../../redux/actions/users.action';
import { Link, useNavigate } from 'react-router-dom';
import { loginUserStart } from '../../redux/actions/login.action';
import { toast } from 'react-toastify';

export default function ProfileEdit() {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    let currentUser = useSelector(state => state.login.loginedUser)

    let [formData, setFormData] = useState(currentUser)

    let {
        name, email, contact, image, role, status
    } = formData;

    const inputChanges = (event) => {
        setFormData((prevValue) => ({
            ...prevValue,
            [event.target.name]: event.target.value
        }))
    }

    const submit = async (event) => {
        event.preventDefault()

        try {
            let id = formData.id;
            delete formData.id;
            dispatch(updateUserStart(formData,id))

            dispatch(loginUserStart({...formData, id}))

            setTimeout(() => {
                toast.success("Profile updated successfully");

                navigate("/admin/profile")
            }, 1000)
        } catch (error) {

        }

    }

    const uploadFile = (event) => {
        const storageRef = ref(storage, event.target.files[0].name);

        const uploadTask = uploadBytesResumable(storageRef, event.target.files[0]);

        uploadTask.on('state_changed',
            (snapshot) => {
                const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                console.log('Upload is ' + progress + '% done');
                switch (snapshot.state) {
                    case 'paused':
                        console.log('Upload is paused');
                        break;
                    case 'running':
                        console.log('Upload is running');
                        break;
                }
            }, (error) => {
                // Handle unsuccessful uploads
            },
            () => {
                getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
                    setFormData((prevValue) => ({
                        ...prevValue,
                        image: downloadURL
                    }))
                });
            }
        );
    }

    return (
        <div className="card">
            <div className='card-header d-flex justify-content-between'>
                <h3>Edit User</h3>
                <Link to="/admin/profile" className='btn btn-primary'>Back</Link>
            </div>
            <div className="card-body">
                <form onSubmit={submit}>
                    <div className="mb-3">
                        <label htmlFor="name" className="form-label">Name</label>
                        <input
                            type="text"
                            className="form-control"
                            id="name"
                            placeholder="Name"
                            value={name}
                            name='name'
                            onChange={inputChanges} />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="email" className="form-label">User Email</label>
                        <input
                            type="email"
                            className="form-control"
                            id="email"
                            placeholder="User email"
                            value={email}
                            name='email'
                            onChange={inputChanges} />
                    </div>

                    <div className="mb-3">
                        <label htmlFor="contact" className="form-label">Contact</label>
                        <input
                            type="number"
                            className="form-control"
                            id="contact"
                            placeholder="Contact"
                            value={contact}
                            name='contact'
                            onChange={inputChanges} />
                    </div>

                    <div className="mb-3">
                        <label htmlFor="image" className="form-label">image</label>
                        <input type="file" name='image' onChange={uploadFile} className="form-control" id="image" style={{
                            height: "auto"
                        }} />

                        <div className='mt-2'>
                            <img src={image} alt="" />
                        </div>
                    </div>

                    <div className="mb-3">
                        <label htmlFor="role" className="form-label">Role</label>
                        <select className='form-control' name='role' defaultValue={role} onChange={inputChanges}>
                            <option value="1">Admin</option>
                            <option value="0">Customer</option>
                        </select>
                    </div>

                    <div className="mb-3">
                        <label htmlFor="status" className="form-label">Status</label>
                        <select className='form-control' name='status' defaultValue={status} onChange={inputChanges}>
                            <option value="1">Active</option>
                            <option value="0">InActive</option>
                        </select>
                    </div>

                    <button className='btn btn-primary'>
                        Update
                    </button>
                </form>
            </div>
        </div>
    )
}
