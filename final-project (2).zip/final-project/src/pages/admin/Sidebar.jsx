import React, { useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { signOut } from "firebase/auth";
import { auth } from '../../firebase.config';
import { useDispatch, useSelector } from 'react-redux';
import { logoutUserStart } from '../../redux/actions/login.action';
import { toast } from 'react-toastify';


export default function Sidebar() {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    let currentUser = useSelector(state => state.login.loginedUser)
   

    const logout = async () => {
        await signOut(auth);

        dispatch(logoutUserStart());

        setTimeout(() => {
            toast.success("Logout user successfully");
            navigate('/login');
        })
    }

    useEffect(() => {
        
    }, [currentUser.id])

    return (
        <ul className="list-group">
            <li className="list-group-item">
                <Link to="/admin/profile">Profile</Link>
            </li>
            <li className="list-group-item">
                <Link to="/admin/orders">Orders</Link>
            </li>
            {
                currentUser.role !== "0" && <>
                    <li className="list-group-item">
                        <Link to="/admin/products">Products</Link>
                    </li>
                    <li className="list-group-item">
                        <Link to="/admin/categories">Categories</Link>
                    </li>
                    <li className="list-group-item">
                        <Link to="/admin/users">Users</Link>
                    </li>
                </>
            }
            <li className="list-group-item">
                <a href="#" onClick={logout}>Logout</a>
            </li>
        </ul>
    )
}
