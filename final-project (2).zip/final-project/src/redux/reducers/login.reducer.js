import {
    LOGIN_USER_SUCCESS,
    LOGOUT_USER_SUCCESS
} from "../constants/login.constant";

const initialState = {
    loginedUser: localStorage.getItem("loginedUser") ?
        JSON.parse(localStorage.getItem("loginedUser")) : {
            contact: '',
            status: '',
            uid: '',
            image: '',
            role: '',
            name: '',
            email: '',
            id: ''
        }
}

export const LoginReducer = (state = initialState, action) => {
    switch (action.type) {

        case LOGIN_USER_SUCCESS:
            localStorage.setItem("loginedUser", JSON.stringify(action.payload))

            return {
                ...state,
                loginedUser: action.payload
            };

        case LOGOUT_USER_SUCCESS:
            localStorage.removeItem("loginedUser");

            return {
                ...state,
                loginedUser: {
                    contact: '',
                    status: '',
                    uid: '',
                    image: '',
                    role: '',
                    name: '',
                    email: '',
                    id: ''
                }
            };

        default:
            return state;
    }
}