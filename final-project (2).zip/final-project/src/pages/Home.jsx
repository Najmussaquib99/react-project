import React, { useEffect } from 'react'
import Banner from '../components/Banner'
import ProductItem from '../components/ProductItem'
import Testimonial from '../components/Testimonial'
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom'

export default function Home() {
    const products = useSelector(state => state.product.products)

    useEffect(() => {

    }, [products.length])
    return (
        <>
            <Banner />
            <div className="product-section">
                <div className="container">
                    <div className="row">

                        <div className="col-md-12 col-lg-3 mb-5 mb-lg-0">
                            <h2 className="mb-4 section-title">Crafted with excellent material.</h2>
                            <p className="mb-4">Donec vitae odio quis nisl dapibus malesuada. Nullam ac aliquet velit. Aliquam vulputate velit imperdiet dolor tempor tristique. </p>
                            <p><Link to='/shop' className="btn">Explore</Link></p>
                        </div>

                        {
                            products.length > 0 && products.slice(0, 3).map((product,index) =>(
                                <ProductItem product={product} key={index} />
                            ))
                        }
                    </div>
                </div>
            </div>

            <Testimonial />
        </>
    )
}
