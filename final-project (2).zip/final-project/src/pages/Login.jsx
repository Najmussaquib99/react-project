import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from '../firebase.config';
import { getUserStart } from '../redux/actions/users.action';
import { toast } from 'react-toastify';
import { loginUserStart } from '../redux/actions/login.action';

let initialState = {
    email: '',
    password: ''
}

export default function Login() {
    const users = useSelector(state => state.user.users);

    const navigate = useNavigate();

    const dispatch = useDispatch();

    let [formData, setFormData] = useState(initialState)

    let { email, password } = formData;

    const inputChanges = (event) => {
        setFormData((prevValue) => ({
            ...prevValue,
            [event.target.name]: event.target.value
        }))
    }

    const submit = async (event) => {
        event.preventDefault()

        try {
            let response = await signInWithEmailAndPassword(auth, formData.email, formData.password)

            let user = users.find((value) => value.uid === response.user.uid);

            dispatch(loginUserStart(user))

            setTimeout(() => {
                toast.success("User Login Successfully")
                navigate('/admin/profile')
            }, 1000)
        } catch (error) {
            toast.error("User Does Not Exist");
        }
    }

    useEffect(() => {
        dispatch(getUserStart());
    }, [])
    return (
        <div className="container">
            <div className="row justify-content-center mt-5 mb-5">
                <div className="col-lg-4 col-md-6 col-sm-6">
                    <div className="card shadow">
                        <div className="card-title text-center border-bottom">
                            <h2 className="p-3">Login</h2>
                        </div>
                        <div className="card-body">
                            <form onSubmit={submit}>
                                <div className="mb-4">
                                    <label htmlFor="email" className="form-label">Email</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="email"
                                        name='email'
                                        value={email}
                                        onChange={inputChanges} />
                                </div>
                                <div className="mb-4">
                                    <label htmlFor="password" className="form-label">Password</label>
                                    <input
                                        type="password"
                                        className="form-control"
                                        id="password"
                                        name='password'
                                        value={password}
                                        onChange={inputChanges} />
                                </div>
                                <div className="d-grid">
                                    <button type="submit" className="btn text-light main-bg">Login</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
