import {
    ADD_ITEM_TO_CART_ERROR,
    ADD_ITEM_TO_CART_START,
    ADD_ITEM_TO_CART_SUCCESS,
    GET_CART_ERROR,
    GET_CART_START,
    GET_CART_SUCCESS
} from "../constants/cart.constant"

// add item to cart
export const addItemToCartStart = (cart) => ({
    type: ADD_ITEM_TO_CART_START,
    payload: cart
})

export const addItemToCartSuccess = (user) => ({
    type: ADD_ITEM_TO_CART_SUCCESS,
    payload: user
})

export const addItemToCartError = (error) => ({
    type: ADD_ITEM_TO_CART_ERROR,
    payload: error
})

// Get cart
export const getCartStart = () => ({
    type: GET_CART_START
})

export const getCartSuccess = (user) => ({
    type: GET_CART_SUCCESS,
    payload: user
})

export const getCartError = (error) => ({
    type: GET_CART_ERROR,
    payload: error
})