import React from 'react'
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom'

export default function Profile() {
    let currentUser = useSelector(state => state.login.loginedUser)

    return (
        <>
            <Link to={'/admin/profile/edit'} className='btn btn-primary mb-5'>Edit Profile</Link>
            <ul className="list-group">
                <li className="list-group-item d-flex justify-content-between">
                    <div>
                        Name
                    </div>
                    <div>{currentUser.name}</div>
                </li>
                <li className="list-group-item d-flex justify-content-between">
                    <div>
                        Email
                    </div>
                    <div>{currentUser.email}</div>
                </li>
                <li className="list-group-item d-flex justify-content-between">
                    <div>
                        Image
                    </div>
                    <div>
                        <img src={currentUser.image} />
                    </div>
                </li>

                <li className="list-group-item d-flex justify-content-between">
                    <div>
                        Contact
                    </div>
                    <div>{currentUser.contact}</div>
                </li>

                <li className="list-group-item d-flex justify-content-between">
                    <div>
                        Role
                    </div>
                    <div>{currentUser.role === "1" ? 'Admin' : "Customer"}</div>
                </li>
            </ul>
        </>
    )
}
