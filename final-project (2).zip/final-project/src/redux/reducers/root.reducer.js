import { combineReducers } from "@reduxjs/toolkit";
import { ProductReducer } from "./product.reducer";
import { CategoryReducer } from "./category.reducer";
import { UserReducer } from "./users.reducer";
import { LoginReducer } from "./login.reducer";
import { CartReducer } from "./cart.reducer";

export const rootReducer = combineReducers({
    product: ProductReducer,
    category: CategoryReducer,
    user: UserReducer,
    login: LoginReducer,
    cart: CartReducer
})

