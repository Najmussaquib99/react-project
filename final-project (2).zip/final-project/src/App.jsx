import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import Footer from "./layouts/Footer";
import Header from "./layouts/Header";
import Router from "./routes/Router";

function App() {
  return (
    <>
      <Header />
      <Router />
      <Footer />

      <ToastContainer />
    </>
  );
}

export default App;
