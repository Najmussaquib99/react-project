import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Home from '../pages/Home'
import About from '../pages/About'
import Shop from '../pages/Shop'
import Contact from '../pages/Contact'
import Cart from '../pages/Cart'
import Checkout from '../pages/Checkout'
import Auth from '../pages/admin/Auth'
import Profile from '../pages/admin/Profile'
import Product from '../pages/admin/products/Product'
import CreateOrEditProduct from '../pages/admin/products/CreateOrEditProduct'
import Category from '../pages/admin/category/Category'
import CreateOrEditCategory from '../pages/admin/category/CreateOrEditCategory'
import User from '../pages/admin/users/User'
import CreateOrUpdateUser from '../pages/admin/users/CreateOrUpdateUser'
import Order from '../pages/admin/orders/Order'
import OrderView from '../pages/admin/orders/OrderView'
import ProductDescription from '../pages/ProductDescription'
import Login from '../pages/Login'
import Register from '../pages/Register'
import ProfileEdit from '../pages/admin/ProfileEdit'

export default function Router() {
  return (
    <Routes>
      {/* front routes */}
      <Route path='/' element={<Home />} />
      <Route path='/:id' element={<ProductDescription />} />
      <Route path='/about-us' element={<About />} />
      <Route path='/shop' element={<Shop />} />
      <Route path='/contact-us' element={<Contact />} />
      <Route path='/cart' element={<Cart />} />
      <Route path='/checkout' element={<Checkout />} />
      <Route path='/login' element={<Login />} />
      <Route path='/register' element={<Register />} />

      {/* admin routes */}
      <Route path='/admin' element={<Auth />}>
        <Route path='profile' element={<Profile />} />
        <Route path='profile/edit' element={<ProfileEdit />} />

        {/* product routes */}
        <Route path='products' element={<Product />} />
        <Route path='product/create' element={<CreateOrEditProduct />} />
        <Route path='product/edit/:id' element={<CreateOrEditProduct />} />

        {/* category routes */}
        <Route path='categories' element={<Category />} />
        <Route path='category/create' element={<CreateOrEditCategory />} />
        <Route path='category/edit/:id' element={<CreateOrEditCategory />} />

        {/* users routes */}
        <Route path='users' element={<User />} />
        <Route path='user/create' element={<CreateOrUpdateUser />} />
        <Route path='user/edit/:id' element={<CreateOrUpdateUser />} />

        {/* orders */}
        <Route path='orders' element={<Order />} />
        <Route path='order/view/:id' element={<OrderView />} />
      </Route>
    </Routes>
  )
}
