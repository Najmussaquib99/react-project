import React from 'react'

export default function OrderView() {
  return (
    <div>OrderView</div>
  )
}
