import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { deleteProductStart, getProductStart } from '../../../redux/actions/product.action';

export default function Product() {
  const products = useSelector(state => state.product.products)

  const dispatch = useDispatch();

  const deleteProduct = (product) => {
    dispatch(deleteProductStart(product));
  }

  useEffect(() => {
    dispatch(getProductStart());
  }, [products.length])
  return (
    <div className="card">
      <div className='card-header d-flex justify-content-between'>
        <h3>Products</h3>
        <Link to="/admin/product/create" className='btn btn-primary'>Add Product</Link>
      </div>
      <div className="card-body">
        <table className="table table-striped ">
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Image</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>Category</th>
              <th>Short Description</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {
              products.length > 0 && products.map((product, index) => (
                <tr key={index}>
                  <th>{index + 1}</th>
                  <td>{product.name}</td>
                  <td><img src={product.image} style={{
                    height: '50px',
                  }} /></td>
                  <td>${product.price}</td>
                  <td>{product.quantity}</td>
                  <td>{product.category}</td>
                  <td>
                    {
                      product.shortDescription
                    }
                  </td>
                  <td>
                    <Link to={`/admin/product/edit/${product.id}`} className='btn btn-warning btn-small mx-2'>
                      <i className="fa-solid fa-pen-to-square"></i>
                    </Link>
                    <button 
                      className='btn btn-danger btn-small'
                      onClick={() => deleteProduct(product)}>
                      <i className="fa-solid fa-pen-to-square"></i>
                    </button>
                  </td>
                </tr>
              ))
            }

          </tbody>
        </table>
      </div>
    </div>
  )
}
