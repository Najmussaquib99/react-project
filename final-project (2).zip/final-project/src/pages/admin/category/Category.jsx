import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom'
import { deleteCategoryStart, getCategoryStart } from '../../../redux/actions/category.action';

export default function Category() {
  const categories = useSelector(state => state.category.categories)

  const dispatch = useDispatch();

  const deleteCategory = (category) => {
    dispatch(deleteCategoryStart(category));
  }

  useEffect(() => {
    dispatch(getCategoryStart())
  }, [categories.length])
  return (
    <div className="card">
      <div className='card-header d-flex justify-content-between'>
        <h3>Categories</h3>
        <Link to="/admin/category/create" className='btn btn-primary'>Add Category</Link>
      </div>
      <div className="card-body">
        <table className="table table-striped ">
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Status</th>

              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {
              categories.length > 0 && categories.map((category, index) => (
                <tr key={index}>
                  <th>{index  + 1}</th>
                  <td>{category.name}</td>
                  <td>{category.status !== '0' ? 'Active': 'InActive'}</td>
                  <td>
                    <Link to={`/admin/category/edit/${category.id}`} className='btn btn-warning btn-small mx-2'>
                      <i className="fa-solid fa-pen-to-square"></i>
                    </Link>
                    <button className='btn btn-danger btn-small' onClick={() => deleteCategory(category)}>
                      <i className="fa-solid fa-pen-to-square"></i>
                    </button>
                  </td>
                </tr>
              ))
            }
          </tbody>
        </table>
      </div>
    </div>
  )
}
