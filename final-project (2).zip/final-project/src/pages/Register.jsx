import { createUserWithEmailAndPassword } from 'firebase/auth';
import React, { useState } from 'react'
import { auth } from '../firebase.config';
import { addUserStart } from '../redux/actions/users.action';
import { useDispatch } from 'react-redux';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const initialState = {
    name: '',
    email: '',
    password: '',
    contact: '',
    image: '',
    role: '0',
    status: 1
}

export default function Register() {
    const dispatch = useDispatch();

    const navigate = useNavigate();

    let [formData, setFormData] = useState(initialState)

    let { name, email, password } = formData;

    const inputChanges = (event) => {
        setFormData((prevValue) => ({
            ...prevValue,
            [event.target.name]: event.target.value
        }))
    }

    const submit = async (event) => {
        event.preventDefault()
        try {
            let user = await signUpUser(formData.email, formData.password)
            formData.uid = user.user.uid;

            delete formData.password;

            dispatch(addUserStart(formData))

            setTimeout(() => {
                toast.success("User Register Successfully");
                navigate("/login");
            }, 1000)

        } catch (error) { }
    }

    const signUpUser = async (email, password) => {
        try {
            return await createUserWithEmailAndPassword(auth, email, password)

        } catch (error) {
            toast.error("User already exists")
        }
    }

    return (
        <div className="container">
            <div className="row justify-content-center mt-5 mb-5">
                <div className="col-lg-6 col-md-8 col-sm-12">
                    <div className="card shadow">
                        <div className="card-title text-center border-bottom">
                            <h2 className="p-3">Register</h2>
                        </div>
                        <div className="card-body">
                            <form onSubmit={submit}>
                                <div className="mb-4">
                                    <label htmlFor="name" className="form-label">Name</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="name"
                                        name='name'
                                        value={name}
                                        onChange={inputChanges} />
                                </div>
                                <div className="mb-4">
                                    <label htmlFor="email" className="form-label">Email</label>
                                    <input
                                        type="email"
                                        className="form-control"
                                        id="email"
                                        name='email'
                                        value={email}
                                        onChange={inputChanges} />
                                </div>
                                <div className="mb-4">
                                    <label htmlFor="password" className="form-label">Password</label>
                                    <input
                                        type="password"
                                        className="form-control"
                                        id="password"
                                        name='password'
                                        value={password}
                                        onChange={inputChanges} />
                                </div>
                                <div className="d-grid">
                                    <button type="submit" className="btn text-light main-bg">Register</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
