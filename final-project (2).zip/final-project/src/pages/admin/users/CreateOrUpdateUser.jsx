import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';
import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { createUserWithEmailAndPassword } from "firebase/auth";
import { auth, storage } from '../../../firebase.config';
import { toast } from 'react-toastify';
import { useDispatch } from 'react-redux';
import { addUserStart } from '../../../redux/actions/users.action';

const initialState = {
  name: '',
  email: '',
  password: '',
  contact: '',
  image: '',
  role: '0',
  status: 0
}

export default function CreateOrUpdateUser() {
  const dispatch = useDispatch();

  let [formData, setFormData] = useState(initialState)

  let {
    name, email, password, contact, image, role, status
  } = formData;

  const inputChanges = (event) => {
    setFormData((prevValue) => ({
      ...prevValue,
      [event.target.name]: event.target.value
    }))
  }

  const submit = async (event) => {
    event.preventDefault()
    try {
      let user =  await signUpUser(formData.email, formData.password)
      formData.uid = user.user.uid;

      delete formData.password;

      dispatch(addUserStart(formData))
       
    } catch (error) {

    }

  }

  const uploadFile = (event) => {
    const storageRef = ref(storage, event.target.files[0].name);

    const uploadTask = uploadBytesResumable(storageRef, event.target.files[0]);

    uploadTask.on('state_changed',
      (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log('Upload is ' + progress + '% done');
        switch (snapshot.state) {
          case 'paused':
            console.log('Upload is paused');
            break;
          case 'running':
            console.log('Upload is running');
            break;
        }
      }, (error) => {
        // Handle unsuccessful uploads
      },
      () => {
        getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
          setFormData((prevValue) => ({
            ...prevValue,
            image: downloadURL
          }))
        });
      }
    );
  }

  const signUpUser = async (email, password) => {
    try {
      return await createUserWithEmailAndPassword(auth, email,password)
     
    } catch (error) {
      toast.error("User already exists")
    }   
  }

  return (
    <div className="card">
      <div className='card-header d-flex justify-content-between'>
        <h3>Add User</h3>
        <Link to="/admin/users" className='btn btn-primary'>Back</Link>
      </div>
      <div className="card-body">
        <form onSubmit={submit}>
          <div className="mb-3">
            <label htmlFor="name" className="form-label">User Name</label>
            <input
              type="text"
              className="form-control"
              id="name"
              placeholder="User Name"
              value={name}
              name='name'
              onChange={inputChanges} />
          </div>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">User Email</label>
            <input
              type="email"
              className="form-control"
              id="email"
              placeholder="User email"
              value={email}
              name='email'
              onChange={inputChanges} />
          </div>

          <div className="mb-3">
            <label htmlFor="password" className="form-label">Password</label>
            <input
              type="password"
              className="form-control"
              id="password"
              placeholder="password"
              value={password}
              name='password'
              onChange={inputChanges} />
          </div>

          <div className="mb-3">
            <label htmlFor="contact" className="form-label">Contact</label>
            <input
              type="number"
              className="form-control"
              id="contact"
              placeholder="Contact"
              value={contact}
              name='contact'
              onChange={inputChanges} />
          </div>

          <div className="mb-3">
            <label htmlFor="image" className="form-label">image</label>
            <input type="file" name='image' onChange={uploadFile} className="form-control" id="image" style={{
              height: "auto"
            }} />

            <div className='mt-2'>
              <img src={image} alt="" />
            </div>
          </div>

          <div className="mb-3">
            <label htmlFor="role" className="form-label">Role</label>
            <select className='form-control' name='role' defaultValue={role} onChange={inputChanges}>
              <option value="1">Admin</option>
              <option value="0">Customer</option>
            </select>
          </div>

          <div className="mb-3">
            <label htmlFor="status" className="form-label">Status</label>
            <select className='form-control' name='status' defaultValue={status} onChange={inputChanges}>
              <option value="1">Active</option>
              <option value="0">InActive</option>
            </select>
          </div>


          <button className='btn btn-primary'>
            Add
          </button>
        </form>
      </div>
    </div>
  )
}
