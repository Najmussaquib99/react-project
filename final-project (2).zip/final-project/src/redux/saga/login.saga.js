import { put, takeLatest } from "redux-saga/effects";
import { LOGIN_USER_START, LOGOUT_USER_START } from "../constants/login.constant";
import { loginUserError, loginUserSuccess, logoutUserError, logoutUserSuccess } from "../actions/login.action";

function* loginUser({payload}) {
    try {
        yield put(loginUserSuccess(payload))
    } catch (error) {
        yield put(loginUserError(error.message))
    }
}


function* logoutUser() {
    try {
        yield put(logoutUserSuccess())
    } catch (error) {
        yield put(logoutUserError(error.message))
    }
}

export default function* login() {
    yield takeLatest(LOGIN_USER_START, loginUser);
    yield takeLatest(LOGOUT_USER_START, logoutUser);
}