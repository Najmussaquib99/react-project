import { GET_CART_SUCCESS } from "../constants/cart.constant";

const initialState = {
    cart: localStorage.getItem("cart") ?
        JSON.parse(localStorage.getItem("cart")) : {
            subTotal: 0,
            grandTotal: 0,
            tax: 0,
            address: {},
            customer: {},
            items: []
        }
}

export const CartReducer = (state = initialState, action) => {
    switch (action.type) {

        case GET_CART_SUCCESS:
            localStorage.setItem("cart", JSON.stringify({...action.payload}))

            return {
                ...state,
                cart: {...action.payload}
            }

            default:
                return state;
    }

}