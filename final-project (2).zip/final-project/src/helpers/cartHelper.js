export const cartHelper = (cart, product ,customer, quantity) => {
    if(cart.items.length > 0) {

    }else {
        cart.items.push({...product, qty: quantity})
    }

    cart.subTotal = 0;
    cart.grandTotal = 0;
    cart.tax = 0;
    for (const item of cart.items) {
        cart.subTotal = cart.subTotal + +item.price * item.qty
    }

    cart.customer = customer

    cart.grandTotal = cart.subTotal + cart.tax;

    return cart;
} 