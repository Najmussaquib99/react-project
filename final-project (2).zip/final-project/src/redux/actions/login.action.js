import { LOGIN_USER_ERROR, LOGIN_USER_START, LOGIN_USER_SUCCESS, LOGOUT_USER_ERROR, LOGOUT_USER_START, LOGOUT_USER_SUCCESS } from "../constants/login.constant"

// Login
export const loginUserStart = (user) => ({
    type: LOGIN_USER_START,
    payload: user
})

export const loginUserSuccess = (user) => ({
    type: LOGIN_USER_SUCCESS,
    payload: user
})

export const loginUserError = (error) => ({
    type: LOGIN_USER_ERROR,
    payload: error
})

// Logout
export const logoutUserStart = () => ({
    type: LOGOUT_USER_START
})

export const logoutUserSuccess = () => ({
    type: LOGOUT_USER_SUCCESS
})

export const logoutUserError = (error) => ({
    type: LOGOUT_USER_ERROR,
    payload: error
})
