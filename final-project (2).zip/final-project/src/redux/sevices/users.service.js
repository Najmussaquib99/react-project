import {
    collection,
    addDoc,
    query,
    getDocs,
    deleteDoc,
    doc,
    updateDoc
} from "firebase/firestore";
import {
    db
} from "../../firebase.config";

export const addUserToFirebase = async (user) => {

    let userRef = collection(db, "users")

    const docRef = await addDoc(userRef, user);

    console.log("Document written with ID: ", docRef.id);
}

export const getUserFromFirebase = async () => {

    let userRef = query(collection(db, "users"))

    const querySnapshot = await getDocs(userRef);

    let users = [];

    querySnapshot.forEach((doc) => {

        let prod = doc.data()

        prod.id = doc.id;

        users.push(prod);
    });

    return users;
}

export const deleteUserFormFirebase = async (user) => {
    await deleteDoc(doc(db, "users", user.id));
}

export const updateUserToFirebase = async (user, id) => {

    let userRef =  doc(db, "users", id);

    await updateDoc(userRef, user);
}