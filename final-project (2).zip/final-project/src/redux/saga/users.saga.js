import { put, takeLatest } from "redux-saga/effects";
import { ADD_USERS_START, DELETE_USERS_START, GET_USERS_START, UPDATE_USERS_START } from "../constants/users.constant";
import { addUserToFirebase, deleteUserFormFirebase, getUserFromFirebase, updateUserToFirebase } from "../sevices/users.service";
import { addUserError, deleteUserError, getUserError, getUserStart, getUserSuccess, updateUserError } from "../actions/users.action";

function* addUser({payload}) {
    try {
        yield addUserToFirebase(payload)
        yield put(getUserStart())
    } catch (error) {
        yield put(addUserError(error.message))
    }
}

function* getUser() {
    try {
        let users = yield getUserFromFirebase()
        yield put(getUserSuccess(users))
    } catch (error) {
        yield put(getUserError(error.message))
    }
}

function* deleteUser({payload}) {
    try {
        yield deleteUserFormFirebase(payload)
        yield put(getUserStart())
    } catch (error) {
        yield put(deleteUserError(error.message))
    }
}


function* updateUser({payload}) {
    try {
        yield updateUserToFirebase(payload.user, payload.id)
        yield put(getUserStart())
    } catch (error) {
        yield put(updateUserError(error.message))
    }
}

export default function* user() {
    yield takeLatest(ADD_USERS_START, addUser);
    yield takeLatest(GET_USERS_START, getUser);
    yield takeLatest(DELETE_USERS_START, deleteUser);
    yield takeLatest(UPDATE_USERS_START, updateUser);
}