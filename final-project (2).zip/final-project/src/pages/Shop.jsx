import React, { useEffect } from 'react'
import { useSelector } from 'react-redux'
import ProductItem from '../components/ProductItem'

export default function Shop() {
    const products = useSelector(state => state.product.products)

    useEffect(() => {

    }, [products.length])

    return (
        <>
            <div className="hero">
                <div className="container">
                    <div className="row justify-content-between">
                        <div className="col-lg-5">
                            <div className="intro-excerpt">
                                <h1>Shop</h1>
                            </div>
                        </div>
                        <div className="col-lg-7">

                        </div>
                    </div>
                </div>
            </div>

            <div className="untree_co-section product-section before-footer-section">
                <div className="container">
                    <div className="row">
                        {
                            products.length > 0 && products.map((product, index) => (
                                <ProductItem product={product} key={index} />
                            ))
                        }
                    </div>
                </div>
            </div>
        </>
    )
}
