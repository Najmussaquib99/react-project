import {
    collection,
    addDoc,
    query,
    getDocs,
    deleteDoc,
    doc,
    updateDoc
} from "firebase/firestore";
import {
    db
} from "../../firebase.config";

export const addProductToFirebase = async (product) => {

    let productRef = collection(db, "products")

    const docRef = await addDoc(productRef, product);

    console.log("Document written with ID: ", docRef.id);
}

export const getProductFromFirebase = async () => {

    let productRef = query(collection(db, "products"))

    const querySnapshot = await getDocs(productRef);

    let products = [];

    querySnapshot.forEach((doc) => {

        let prod = doc.data()

        prod.id = doc.id;

        products.push(prod);
    });

    return products;
}

export const deleteProductFormFirebase = async (product) => {
    await deleteDoc(doc(db, "products", product.id));
}

export const updateProductToFirebase = async (product, id) => {

    let productRef =  doc(db, "products", id);

    await updateDoc(productRef, product);
}