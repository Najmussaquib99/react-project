import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate, useParams } from 'react-router-dom'
import { toast } from 'react-toastify';
import { cartHelper } from '../helpers/cartHelper';
import { addItemToCartStart } from '../redux/actions/cart.action';

export default function ProductDescription() {
    const products = useSelector(state => state.product.products)
    let currentUser = useSelector(state => state.login.loginedUser)
    let cart = useSelector(state => state.cart.cart)

    const navigate = useNavigate();
    const dispatch = useDispatch();

    const [quantity, setQuantity] = useState(0);

    let { id } = useParams();

    let product = products.find(prod => prod.id === id);

    const addProductToCart = () => {
        if(currentUser.id === '') {
            toast.error("Please Login first");

            navigate('/login');
        }

        let response = cartHelper({...cart}, {...product}, {...currentUser}, quantity)

        dispatch(addItemToCartStart(response))
    }

    if (!product) {
        return (
            <section className="page_404">
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12">
                            <div className="four_zero_four_bg">
                                <h1 className="text-center ">404</h1>
                            </div>

                            <div className="contant_box_404">
                                <h3 className="h2">
                                    Product is not available
                                </h3>

                                <Link to='/' className="link_404">Go to Home</Link>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        )
    }

    return (
        <div>
            <div className="row d-flex justify-content-center">
                <div className="col-md-12">
                    <div className="card" style={{
                        height: "auto",
                        paddingTop: "5%"
                    }}>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="images p-3">
                                    <div className="text-center p-4">
                                        <img id="main-image" src={product.image} width="250" />
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="product p-4">
                                    <div className="d-flex justify-content-between align-items-center">
                                        <Link to="/" className='text-decoration-none'>Back</Link>
                                    </div>
                                    <div className="mt-4 mb-3">
                                        <span className="text-uppercase text-muted brand">{product.category}</span>
                                        <h5 className="text-uppercase">{product.name}</h5>
                                        <div className="price d-flex flex-row align-items-center">
                                            <span className="act-price">${product.price}</span>
                                        </div>
                                    </div>
                                    <p className="about">
                                        {product.shortDescription}
                                    </p>
                                    <p className="about">
                                        {product.description}
                                    </p>

                                    <section>
                                            <p className="qty">
                                                <label htmlFor="qty" style={{
                                                    marginRight: "20px"
                                                }}>Quantity:</label>
                                                <button 
                                                    className="qtyminus" 
                                                    aria-hidden="true"
                                                    onClick={() => {
                                                        if(quantity >= 1) {
                                                            setQuantity(quantity - 1)
                                                        }
                                                    }}
                                                >-</button>
                                                <input 
                                                    type="number" 
                                                    name="qty" 
                                                    id="qty" 
                                                    min="1"
                                                    value={quantity}
                                                    onChange={(event) => setQuantity(event.target.value)} />
                                                <button 
                                                    className="qtyplus" 
                                                    aria-hidden="true"
                                                    onClick={() => setQuantity(quantity + 1)}    
                                                >+</button>
                                            </p>
                                        
                                    </section>

                                    <div className="cart mt-4 align-items-center">
                                        <button className="btn btn-danger text-uppercase mr-2 px-4" onClick={addProductToCart}>Add to cart</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
