import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import { addCategoryStart, updateCategoryStart } from '../../../redux/actions/category.action'

let initialState = {}

export default function CreateOrEditCategory() {
  const categories = useSelector(state => state.category.categories)

  const { id } = useParams();

  if (id) {
    let category = categories.find(cat => cat.id === id);

    if (category)
      initialState = category;

  } else {
    initialState = {
      name: '',
      status: 0
    }
  }


  const navigate = useNavigate();

  const dispatch = useDispatch();

  let [formData, setFormData] = useState(initialState)

  let { name, status } = formData;

  const inputChanges = (event) => {
    setFormData((prevValue) => ({
      ...prevValue,
      [event.target.name]: event.target.value
    }))
  }

  const submit = (event) => {
    event.preventDefault()

    try {

      if (id) {
        dispatch(updateCategoryStart(formData, id))

        setTimeout(() => {
          toast.success("Category updated successfully")

          navigate('/admin/categories')
        })

      } else {
        dispatch(addCategoryStart(formData));

        setTimeout(() => {
          toast.success("Category added successfully")

          navigate('/admin/categories')
        })
      }
    } catch (error) {
      setTimeout(() => {
        toast.error(error.message)
      })
    }

  }
  return (
    <div className="card">
      <div className='card-header d-flex justify-content-between'>
        <h3>{ id ? 'Update' : 'Add'} Category</h3>
        <Link to="/admin/categories" className='btn btn-primary'>Back</Link>
      </div>
      <div className="card-body">
        <form onSubmit={submit}>
          <div className="mb-3">
            <label htmlFor="name" className="form-label">Category Name</label>
            <input
              type="text"
              className="form-control"
              id="name"
              placeholder="Category Name"
              name='name'
              value={name}
              onChange={inputChanges} />
          </div>

          <div className="mb-3">
            <label htmlFor="status" className="form-label">Status</label>
            <select
              className='form-control'
              defaultValue={status}
              name='status'
              onChange={inputChanges}>
              <option value="1">Active</option>
              <option value="0">InActive</option>
            </select>
          </div>

          <button className='btn btn-primary'>
           { id ? 'Update' : 'Add'}
          </button>
        </form>
      </div>
    </div>
  )
}
