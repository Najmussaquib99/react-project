import {
    collection,
    addDoc,
    query,
    getDocs,
    deleteDoc,
    doc,
    updateDoc
} from "firebase/firestore";
import {
    db
} from "../../firebase.config";

export const addCategoryToFirebase = async (category) => {

    let categoryRef = collection(db, "categories")

    const docRef = await addDoc(categoryRef, category);

    console.log("Document written with ID: ", docRef.id);
}

export const getCategoryFromFirebase = async () => {

    let categoryRef = query(collection(db, "categories"))

    const querySnapshot = await getDocs(categoryRef);

    let categories = [];

    querySnapshot.forEach((doc) => {

        let prod = doc.data()

        prod.id = doc.id;

        categories.push(prod);
    });

    return categories;
}

export const deleteCategoryFormFirebase = async (category) => {
    await deleteDoc(doc(db, "categories", category.id));
}

export const updateCategoryToFirebase = async (category, id) => {

    let categoryRef =  doc(db, "categories", id);

    await updateDoc(categoryRef, category);
}