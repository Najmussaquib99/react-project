// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyATLFJAYpJtL1CWdKPFAKBG7djpc51uKdg",
  authDomain: "wereact3pm.firebaseapp.com",
  projectId: "wereact3pm",
  storageBucket: "wereact3pm.appspot.com",
  messagingSenderId: "230150524773",
  appId: "1:230150524773:web:276a20777fc0d897d09b8c"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
export const db = getFirestore(app);

// Initialize Cloud Storage and get a reference to the service
export const storage = getStorage(app);

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app);