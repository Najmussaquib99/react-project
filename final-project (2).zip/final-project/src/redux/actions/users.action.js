import { ADD_USERS_ERROR, ADD_USERS_START, ADD_USERS_SUCCESS, DELETE_USERS_ERROR, DELETE_USERS_START, DELETE_USERS_SUCCESS, GET_USERS_ERROR, GET_USERS_START, GET_USERS_SUCCESS, UPDATE_USERS_ERROR, UPDATE_USERS_START, UPDATE_USERS_SUCCESS } from "../constants/users.constant"

// add
export const addUserStart = (user) => ({
    type: ADD_USERS_START,
    payload: user
})

export const addUserSuccess = (user) => ({
    type: ADD_USERS_SUCCESS,
    payload: user
})

export const addUserError = (error) => ({
    type: ADD_USERS_ERROR,
    payload: error
})

// Get
export const getUserStart = () => ({
    type: GET_USERS_START
})

export const getUserSuccess = (user) => ({
    type: GET_USERS_SUCCESS,
    payload: user
})

export const getUserError = (error) => ({
    type: GET_USERS_ERROR,
    payload: error
})


// Delete
export const deleteUserStart = (user) => ({
    type: DELETE_USERS_START,
    payload: user
})

export const deleteUserSuccess = (user) => ({
    type: DELETE_USERS_SUCCESS,
    payload: user
})

export const deleteUserError = (error) => ({
    type: DELETE_USERS_ERROR,
    payload: error
})

// update
export const updateUserStart = (user, id) => ({
    type: UPDATE_USERS_START,
    payload: {id, user}
})

export const updateUserSuccess = (user, id) => ({
    type: UPDATE_USERS_SUCCESS,
    payload: {id, user}
})

export const updateUserError = (error) => ({
    type: UPDATE_USERS_ERROR,
    payload: error
})