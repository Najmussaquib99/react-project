import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate, useParams } from 'react-router-dom'
import { addProductStart, updateProductStart } from '../../../redux/actions/product.action';
import { storage } from '../../../firebase.config';
import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';
import { toast } from 'react-toastify';

let initialState = {}

export default function CreateOrEditProduct() {
  const products = useSelector(state => state.product.products)
  const categories = useSelector(state => state.category.categories)

  let { id } = useParams();

  if (id) {
    let product = products.find(prod => prod.id === id);

    if (product)
      initialState = product;

  } else {
    initialState = {
      name: '',
      price: 0,
      shortDescription: '',
      description: '',
      quantity: 0,
      image: '',
      status: 0,
      category: ''
    }
  }

  const dispatch = useDispatch();

  const navigate = useNavigate();

  let [formData, setFormData] = useState(initialState);

  let {
    name, price, shortDescription, description, quantity, image, status, category
  } = formData

  const inputChanges = (event) => {
    setFormData((prevValue) => ({
      ...prevValue,
      [event.target.name]: event.target.value
    }))
  }

  const submit = (event) => {
    event.preventDefault()
    try {

      if (id) {
        dispatch(updateProductStart(formData, id))

        setTimeout(() => {
          toast.success("Product updated successfully")

          navigate('/admin/products')
        })

      } else {
        dispatch(addProductStart(formData))

        setTimeout(() => {
          toast.success("Product added successfully")

          navigate('/admin/products')
        })
      }

    } catch (error) {
      setTimeout(() => {
        toast.error(error.message)
      })
    }

  }

  const uploadFile = (event) => {
    const storageRef = ref(storage, event.target.files[0].name);

    const uploadTask = uploadBytesResumable(storageRef, event.target.files[0]);

    uploadTask.on('state_changed',
      (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log('Upload is ' + progress + '% done');
        switch (snapshot.state) {
          case 'paused':
            console.log('Upload is paused');
            break;
          case 'running':
            console.log('Upload is running');
            break;
        }
      }, (error) => {
        // Handle unsuccessful uploads
      },
      () => {
        getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
          setFormData((prevValue) => ({
            ...prevValue,
            image: downloadURL
          }))
        });
      }
    );
  }

  return (
    <div className="card">
      <div className='card-header d-flex justify-content-between'>
        <h3>{ id ? 'Update' : 'Add'} Product</h3>
        <Link to="/admin/products" className='btn btn-primary'>Back</Link>
      </div>
      <div className="card-body">
        <form onSubmit={submit}>

          <div className="mb-3">
            <label htmlFor="name" className="form-label">Product Name</label>
            <input
              type="text"
              className="form-control"
              id="name"
              placeholder="Product Name"
              name='name'
              value={name}
              onChange={inputChanges} />
          </div>

          <div className="mb-3">
            <label htmlFor="Price" className="form-label">Price</label>
            <input
              type="number"
              className="form-control"
              id="Price"
              placeholder="Price"
              name='price'
              value={price}
              onChange={inputChanges} />
          </div>

          <div className="mb-3">
            <label htmlFor="shortDescription" className="form-label">Short Description</label>
            <textarea
              className="form-control"
              id="shortDescription"
              rows="5"
              placeholder="Short Description"
              name='shortDescription'
              value={shortDescription}
              onChange={inputChanges}
            ></textarea>
          </div>

          <div className="mb-3">
            <label htmlFor="description" className="form-label">Description</label>
            <textarea
              className="form-control"
              id="description"
              rows="10"
              placeholder="Description"
              name='description'
              value={description}
              onChange={inputChanges}
            ></textarea>
          </div>

          <div className="mb-3">
            <label htmlFor="quantity" className="form-label">Quantity</label>
            <input
              type="number"
              className="form-control"
              id="quantity"
              placeholder="Quantity"
              name='quantity'
              value={quantity}
              onChange={inputChanges} />
          </div>

          <div className="mb-3">
            <label htmlFor="image" className="form-label">image</label>
            <input
              type="file"
              className="form-control"
              id="image"
              name='file'
              onChange={uploadFile}
              style={{
                height: "auto"
              }} />

            <div className='mt-2'>
              <img src={image} alt="" />
            </div>
          </div>

          <div className="mb-3">
            <label htmlFor="category" className="form-label">category</label>
            <select
              className='form-control'
              name='category'
              defaultValue={category}
              onChange={inputChanges}>
                <option value="" hidden>Select Category</option>
              {
                categories.length > 0 && categories.map((category,index) => {
                  if(category.status === '1') {
                    return (
                      <option value={category.name} key={index}>{category.name}</option>
                    )
                  }
                })
              }
             
            </select>
          </div>

          <div className="mb-3">
            <label htmlFor="status" className="form-label">Status</label>
            <select
              className='form-control'
              name='status'
              defaultValue={status}
              onChange={inputChanges}>
              <option value="1">Active</option>
              <option value="0">InActive</option>
            </select>
          </div>

          <button className='btn btn-primary'>
            {
              id ? 'Update' : 'Add'
            }
          </button>
        </form>
      </div>
    </div>
  )
}
