import { getAuth } from 'firebase/auth';
import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { deleteUserStart } from '../../../redux/actions/users.action';

export default function User() {
  const users = useSelector(state => state.user.users);
  const dispatch = useDispatch();

  useEffect(() => { }, [users.length])

  const deleteUser = async (user) => {
    dispatch(deleteUserStart(user))  
  }
  return (
    <div className="card">
      <div className='card-header d-flex justify-content-between'>
        <h3>Users</h3>
        <Link to="/admin/user/create" className='btn btn-primary'>Add User</Link>
      </div>
      <div className="card-body">
        <table className="table table-striped ">
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Image</th>
              <th>Email</th>
              <th>Contact</th>
              <th>Role</th>
              <th>Status</th>

              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {
              users.length > 0 && users.map((user, index) => (
                <tr key={index}>
                  <th>{index + 1}</th>
                  <td>{user.name}</td>
                  <td><img src={user.image} style={{
                    height: '50px',
                  }} /></td>
                  <td>{user.email}</td>
                  <td>{user.contact}</td>
                  <td>{user.role === '1' ? 'Admin' : 'Customer'}</td>
                  <td>{user.status === '1' ? 'Active' : 'Inactive'}</td>

                  <td>
                    <Link className='btn btn-warning btn-small mx-2'>
                      <i className="fa-solid fa-pen-to-square"></i>
                    </Link>
                    <button className='btn btn-danger btn-small' onClick={() => deleteUser(user)}>
                      <i className="fa-solid fa-pen-to-square"></i>
                    </button>
                  </td>
                </tr>
              ))
            }
          </tbody>
        </table>
      </div>
    </div>
  )
}
