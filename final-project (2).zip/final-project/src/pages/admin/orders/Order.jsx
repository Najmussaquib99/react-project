import React from 'react'
import { Link } from 'react-router-dom'

export default function Order() {
  return (
    <div className="card">
      <div className='card-header d-flex justify-content-between'>
        <h3>Users</h3>
      </div>
      <div className="card-body">
        <table class="table table-striped ">
          <thead>
            <tr>
              <th>Id</th>
              <th>Customer Name</th>
              <th>Sub Total</th>
              <th>Tax</th>
              <th>Grand Total</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Deepak</td>
              <td>$12.25</td>
              <td>$0</td>
              <td>$12.25</td>
              <td>
                <Link className='btn btn-warning btn-small mx-2'>
                  <i class="fa-solid fa-eye"></i>
                </Link>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}
