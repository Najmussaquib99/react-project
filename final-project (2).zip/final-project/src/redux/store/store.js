import { configureStore } from "@reduxjs/toolkit";
import createSagaMiddleware from "redux-saga";
import { rootReducer } from "../reducers/root.reducer";
import rootSaga from "../saga/root.saga";

const sagaMiddleware = createSagaMiddleware();

let store = configureStore({
    reducer: rootReducer,
    middleware: [sagaMiddleware],
    devTools: process.env.NODE_ENV !== "production" ? true: false
})

sagaMiddleware.run(rootSaga)

export default store;