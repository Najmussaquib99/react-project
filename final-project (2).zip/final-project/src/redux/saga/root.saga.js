import { all, fork } from 'redux-saga/effects'
import product from './product.saga'
import category from './category.saga'
import user from './users.saga'
import login from './login.saga'
import cart from './cart.saga'

export default function* rootSaga() {
    yield all([
        fork(product),
        fork(category),
        fork(user),
        fork(login),
        fork(cart)
    ])
}