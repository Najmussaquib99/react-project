import React, { useEffect } from 'react'
import { useSelector } from 'react-redux'
import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import Sidebar from './Sidebar';

const customerRoute = [
    "profile",
    "orders"
]

export default function Auth() {
    const navigate = useNavigate();
    let location = useLocation();

    let currentUser = useSelector(state => state.login.loginedUser)

    useEffect(() => {
        if (currentUser.id == '') {
            navigate('/login');
        } else {
            let authorizeRoute = 0;
            if (currentUser.role === "0") {
                for (const route of customerRoute) {
                    if (!location.pathname.includes(route)) {
                        authorizeRoute++;
                    } else {
                        authorizeRoute = 0;
                        break;
                    }
                }
            }

            if (authorizeRoute) {
                navigate("/admin/profile")
            }
        }
    }, [currentUser.id, location.pathname])
    return (
        <div className='container-fluid bg-white'>
            <div className='container pt-4'>
                <div className='row'>
                    <div className="col-sm-3">
                        <Sidebar />
                    </div>
                    <div className="col-sm-9">
                        <Outlet />
                    </div>
                </div>
            </div>
        </div>
    )
}
